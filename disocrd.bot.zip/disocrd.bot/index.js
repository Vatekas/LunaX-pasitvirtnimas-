require('dotenv').config();
const { Client, GatewayIntentBits, Collection } = require('discord.js');
const fs = require('fs');
const path = require('path');
const express = require('express');

// Sukuriame mini web-serverį, kuris BŪTINAS Render.com nemokamam planui
const app = express();
const port = process.env.PORT || 3000;
app.get('/', (req, res) => res.send('LunaX Botas veikia!'));
app.listen(port, () => console.log(`[VTDC] Web serveris paleistas ant porto ${port} (Render palaikymui)`));

const client = new Client({ 
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages
    ] 
});

client.commands = new Collection();

// Load Commands
const commandsPath = path.join(__dirname, 'commands');
if (fs.existsSync(commandsPath)) {
    const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
    for (const file of commandFiles) {
        const filePath = path.join(commandsPath, file);
        const command = require(filePath);
        if ('data' in command && 'execute' in command) {
            client.commands.set(command.data.name, command);
        }
    }
} else {
    console.warn('[VTDC] "commands" aplankas nerastas, sukurkite ji ir pridekite komandas.');
}

// Load Events
const eventsPath = path.join(__dirname, 'events');
if (fs.existsSync(eventsPath)) {
    const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));
    for (const file of eventFiles) {
        const filePath = path.join(eventsPath, file);
        const event = require(filePath);
        if (event.once) {
            client.once(event.name, (...args) => event.execute(...args, client));
        } else {
            client.on(event.name, (...args) => event.execute(...args, client));
        }
    }
} else {
    console.warn('[VTDC] "events" aplankas nerastas, sukurkite ji ir pridekite eventus.');
}

if (!process.env.DISCORD_TOKEN) {
    console.error('[KLAIDA] DISCORD_TOKEN nerastas .env faile. Botas negali prisijungti.');
    process.exit(1);
}

client.login(process.env.DISCORD_TOKEN).catch(err => {
    console.error("[KLAIDA] Nepavyko prisijungti prie Discord. Patikrinkite ar teisingas DISCORD_TOKEN .env faile.");
    console.error(err);
});
