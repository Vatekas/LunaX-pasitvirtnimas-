@echo off
chcp 65001 >nul
cd /d "%~dp0"
title LunaX.LT Bot Manager
color 0A

:MENU
cls
echo =================================================
echo   VTDC - LUNAX BOT MANAGER
echo =================================================
echo.
echo 1. Install bot in Server (Instaliuoti priedus)
echo 2. Start Bot in Background (Paleisti fone)
echo 3. Stop Bot (Sustabdyti bota)
echo 4. Exit (Iseiti)
echo.
set /p choice="Pasirinkite (1/2/3/4): "

if "%choice%"=="1" goto INSTALL
if "%choice%"=="2" goto START
if "%choice%"=="3" goto STOP
if "%choice%"=="4" goto EXIT

:INSTALL
echo.
echo [VTDC] Pradedamas instaliavimas...
powershell -ExecutionPolicy Bypass -File "%~dp0install.ps1"
echo [VTDC] Instaliacijos procesas baigtas!
pause
goto MENU

:START
echo.
echo [VTDC] Paleidziamas botas fone...
call npx pm2 start index.js --name "LunaXBot"
call npx pm2 save
echo.
echo [VTDC] Botas sekmingai veikia fone! Dabar galite isjungti si langa (X), botas VIS TIEK VEIKS!
pause
goto MENU

:STOP
echo.
echo [VTDC] Stabdomas botas...
call npx pm2 stop "LunaXBot"
echo [VTDC] Botas isjungtas.
pause
goto MENU

:EXIT
exit
